# @scoria/ui Component Registry

> Read by Build stage agents for component resolution decisions.
> This file eliminates the need to read 14 individual source files during pipeline dispatch.

## How to Use This File

1. **Before composing a page**, scan this registry to see what components exist.
2. **Use primitives** (Button, Card, Input, Dialog) as building blocks for custom sections.
3. **Use domain components** when the brief calls for their exact purpose (e.g., `pricing_tiers` -> `PricingCard`).
4. **Check "Components That DO NOT Exist"** before importing anything -- some names appear in old directives but have no source file.
5. **All components** use `forwardRef`, `cn()` for class merging, and design token classes from `DESIGN.md`.

---

## Primitives

Source: `packages/ui/src/components/`

### Button

**File:** `button.tsx`
**Import:** `import { Button } from '@scoria/ui'`

Multi-variant button with Radix Slot support for `asChild` composition.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `variant` | `'default' \| 'destructive' \| 'outline' \| 'secondary' \| 'ghost' \| 'link'` | `'default'` | Visual style |
| `size` | `'default' \| 'sm' \| 'lg' \| 'icon'` | `'default'` | Size preset |
| `asChild` | `boolean` | `false` | Render as child element (Radix Slot) |
| `className` | `string` | -- | Additional CSS classes |

Also extends all native `<button>` HTML attributes.

### Card

**File:** `card.tsx`
**Import:** `import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@scoria/ui'`

Composable card container with five sub-components. All sub-components accept `className` and standard `<div>` attributes.

| Sub-component | Description |
|--------------|-------------|
| `Card` | Outer container -- rounded border, white bg, shadow |
| `CardHeader` | Top section with vertical spacing (`p-6`) |
| `CardTitle` | Heading text -- `font-heading`, `text-xl`, `font-semibold` |
| `CardDescription` | Subtitle text -- `text-sm`, `text-neutral-500` |
| `CardContent` | Body section (`p-6 pt-0`) |
| `CardFooter` | Bottom section with flex row alignment (`p-6 pt-0`) |

### Dialog

**File:** `dialog.tsx`
**Import:** `import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription, DialogClose, DialogPortal, DialogOverlay } from '@scoria/ui'`

Radix UI dialog with animated overlay and content panel.

| Sub-component | Description |
|--------------|-------------|
| `Dialog` | Root provider (Radix `Root`) |
| `DialogTrigger` | Element that opens the dialog |
| `DialogContent` | Centered modal panel with close animation |
| `DialogHeader` | Top layout container for title/description |
| `DialogFooter` | Bottom layout container for action buttons |
| `DialogTitle` | Modal heading -- `font-heading`, `text-lg`, `font-semibold` |
| `DialogDescription` | Modal description text -- `text-sm`, `text-neutral-500` |
| `DialogClose` | Close trigger element |
| `DialogPortal` | Portal wrapper |
| `DialogOverlay` | Background overlay with fade animation |

### Input

**File:** `input.tsx`
**Import:** `import { Input } from '@scoria/ui'`

Styled text input with focus ring and disabled state.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `type` | `string` | -- | HTML input type |
| `className` | `string` | -- | Additional CSS classes |

Also extends all native `<input>` HTML attributes.

---

## Domain Components

Source: `packages/ui/src/domain/`

### HeroSection -- HH-relevant

**File:** `HeroSection.tsx`
**Import:** `import { HeroSection } from '@scoria/ui'`

Full-width hero with headline, optional subheadline, CTA button/link, and children slot for media.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `headline` | `string` | *required* | Primary heading text |
| `subheadline` | `string` | -- | Secondary text below headline |
| `ctaText` | `string` | -- | CTA button label |
| `ctaHref` | `string` | -- | If set, CTA renders as `<a>` link instead of Button |
| `onCtaClick` | `() => void` | -- | Click handler (used when `ctaHref` is not set) |
| `backgroundVariant` | `'light' \| 'dark' \| 'gradient'` | `'light'` | Background color scheme |
| `align` | `'left' \| 'center'` | `'center'` | Text alignment; `left` enables split layout with children beside text |
| `children` | `ReactNode` | -- | Media/content slot (images, video, etc.) |
| `className` | `string` | -- | Additional CSS classes |

### PricingCard -- HH-relevant

**File:** `PricingCard.tsx`
**Import:** `import { PricingCard } from '@scoria/ui'`

Pricing plan card with feature list, CTA, and optional "Recommended" highlight badge.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `planName` | `string` | *required* | Plan display name |
| `price` | `string` | *required* | Price text (e.g., `"$49"`) |
| `period` | `string` | -- | Billing period (e.g., `"/month"`) |
| `description` | `string` | -- | Plan description below price |
| `features` | `string[]` | *required* | List of included features (rendered with check icons) |
| `ctaText` | `string` | -- | CTA button label |
| `ctaHref` | `string` | -- | If set, CTA renders as `<a>` link |
| `onCtaClick` | `() => void` | -- | Click handler |
| `highlighted` | `boolean` | `false` | Adds border accent, shadow, and "Recommended" banner |
| `className` | `string` | -- | Additional CSS classes |

### CoursePlayer -- HH-relevant

**File:** `CoursePlayer.tsx`
**Import:** `import { CoursePlayer } from '@scoria/ui'`

Course viewer layout with collapsible sidebar navigation and main content area. Sidebar shows module/lesson tree with completion indicators.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `modules` | `CourseModule[]` | *required* | Array of `{ id, title, lessons: CourseLesson[] }` |
| `currentLessonId` | `string` | -- | ID of the currently active lesson |
| `onLessonSelect` | `(lessonId: string) => void` | -- | Callback when a lesson is clicked |
| `sidebarOpen` | `boolean` | `true` | Whether sidebar is visible |
| `onSidebarToggle` | `() => void` | -- | Callback for sidebar toggle (controlled mode) |
| `children` | `ReactNode` | *required* | Lesson content rendered in main area |
| `className` | `string` | -- | Additional CSS classes |

**Supporting types:**
- `CourseModule`: `{ id: string, title: string, lessons: CourseLesson[] }`
- `CourseLesson`: `{ id: string, title: string, completed?: boolean }`

### DashboardSidebar -- PHEDRIS-only

**File:** `DashboardSidebar.tsx`
**Import:** `import { DashboardSidebar } from '@scoria/ui'`

Vertical icon sidebar with nav items, team member avatars, and collapse support.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `navItems` | `NavItem[]` | *required* | Array of `{ id, label, icon: ReactNode }` |
| `activeItem` | `string` | -- | ID of the currently active nav item |
| `teamMembers` | `TeamMember[]` | `[]` | Array of `{ id, name, initial, online?, className? }` |
| `collapsed` | `boolean` | `true` | Icon-only (true) or expanded with labels (false) |
| `onNavClick` | `(id: string) => void` | -- | Nav item click handler |
| `onTeamClick` | `(id: string) => void` | -- | Team avatar click handler |
| `logo` | `ReactNode` | `'P'` | Logo content in top badge |
| `surface` | `'default' \| 'elevated' \| 'inset'` | `'default'` | Background surface variant |
| `className` | `string` | -- | Additional CSS classes |

### DashboardTopBar -- PHEDRIS-only

**File:** `DashboardTopBar.tsx`
**Import:** `import { DashboardTopBar } from '@scoria/ui'`

Horizontal top bar with logo, breadcrumbs, search trigger, notification bell, and user avatar.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `breadcrumbs` | `Breadcrumb[]` | `[]` | Array of `{ label, href?, active? }` |
| `logoText` | `string` | `'PHEDRIS'` | Logo text |
| `logoSuffix` | `string` | `'.AI'` | Suffix after logo text (dimmed) |
| `notificationCount` | `number` | `0` | Unread notification count (0 hides badge) |
| `user` | `TopBarUser` | -- | `{ name, initial, avatarUrl?, className? }` |
| `onSearch` | `() => void` | -- | Search button click handler |
| `onNotificationClick` | `() => void` | -- | Notification bell click handler |
| `onUserClick` | `() => void` | -- | User avatar click handler |
| `searchPlaceholder` | `string` | `'Search tasks, docs, people...'` | Search input placeholder |
| `searchShortcut` | `string` | `'Cmd+K'` | Keyboard shortcut label |
| `className` | `string` | -- | Additional CSS classes |

### TaskCard -- PHEDRIS-only

**File:** `TaskCard.tsx`
**Import:** `import { TaskCard } from '@scoria/ui'`

Compact task card for kanban boards with priority dot, assignee avatar, labels, and due date.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `title` | `string` | *required* | Task title text |
| `status` | `TaskStatus` | *required* | One of: `'todo'`, `'in_progress'`, `'in_review'`, `'done'` |
| `priority` | `TaskPriority` | *required* | One of: `'urgent'`, `'high'`, `'normal'`, `'low'` |
| `project` | `TaskProject` | -- | `{ id: number, name: string, color: string }` |
| `assignee` | `TaskAssignee` | -- | `{ email, name, avatar?, initial?, className? }` |
| `dueDate` | `string \| null` | -- | Display date string (e.g., `"Mar 26"`) |
| `labels` | `TaskLabel[]` | `[]` | Array of `{ name: string, color: string }` |
| `done` | `boolean` | -- | Override done state (otherwise derived from `status === 'done'`) |
| `onCardClick` | `() => void` | -- | Card click handler |
| `className` | `string` | -- | Additional CSS classes |

### KanbanColumn -- PHEDRIS-only

**File:** `KanbanColumn.tsx`
**Import:** `import { KanbanColumn } from '@scoria/ui'`

Column container for kanban boards with header dot, title, count badge, and scrollable card list.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `title` | `string` | *required* | Column heading (e.g., `"In Progress"`) |
| `status` | `string` | *required* | Status key (set as `data-status` attribute) |
| `count` | `number` | -- | Task count override (defaults to children count) |
| `dotColor` | `string` | `'bg-neutral-400'` | Header dot color (Tailwind class or CSS value) |
| `dotColorIsCSS` | `boolean` | `false` | If true, `dotColor` is applied as inline `backgroundColor` |
| `size` | `'default' \| 'fixed'` | `'default'` | `default` = fluid flex, `fixed` = 220px fixed width |
| `children` | `ReactNode` | -- | TaskCard components |
| `className` | `string` | -- | Additional CSS classes |

### ChatMessage -- PHEDRIS-only

**File:** `ChatMessage.tsx`
**Import:** `import { ChatMessage } from '@scoria/ui'`

Chat bubble with role-based alignment, optional rich cards, and timestamp.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `role` | `'user' \| 'assistant'` | *required* | Message sender (controls alignment and bubble color) |
| `text` | `string` | *required* | Message text content |
| `cards` | `CardData[]` | `[]` | Rich cards: `{ card_type: string, data: Record<string, unknown> }` |
| `timestamp` | `string` | -- | Display time (e.g., `"2:14 PM"`) |
| `renderCard` | `(card, index) => ReactNode` | -- | Custom card renderer |
| `className` | `string` | -- | Additional CSS classes |

### ChatInput -- PHEDRIS-only

**File:** `ChatInput.tsx`
**Import:** `import { ChatInput } from '@scoria/ui'`

Chat input bar with text field and send button. Sends on Enter key.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `onSend` | `(text: string) => void` | -- | Callback with trimmed message text |
| `placeholder` | `string` | `'Ask PHEDRIS anything...'` | Input placeholder |
| `disabled` | `boolean` | `false` | Disables input and send button |
| `surface` | `'default' \| 'elevated' \| 'inset'` | `'default'` | Background surface variant |
| `className` | `string` | -- | Additional CSS classes |

### ActivityItem -- PHEDRIS-only

**File:** `ActivityItem.tsx`
**Import:** `import { ActivityItem } from '@scoria/ui'`

Activity feed entry with icon, description text, timestamp, and optional project tag.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `icon` | `ReactNode` | *required* | Icon content (emoji string or React element) |
| `iconClassName` | `string` | `'bg-neutral-100'` | Icon container background class |
| `text` | `ReactNode` | *required* | Activity description (supports inline `<b>`/`<strong>`) |
| `timestamp` | `string` | *required* | Display time (e.g., `"2 min ago"`) |
| `projectTag` | `ActivityProjectTag` | -- | `{ name: string, color: string }` |
| `className` | `string` | -- | Additional CSS classes |

### DailyBreakdownGrid -- HH-relevant

**File:** `DailyBreakdownGrid.tsx`
**Import:** `import { DailyBreakdownGrid } from '@scoria/ui'`

Bento-style grid of day cards with asymmetric layout (4-col top row, 3-col bottom row). Renders day number, title, and description per card.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `days` | `DayItem[]` | *required* | Array of `{ day: number, title: string, description: string }` |
| `heading` | `string` | -- | Optional section heading above the grid |
| `className` | `string` | -- | Additional CSS classes |

### TestimonialCard -- HH-relevant

**File:** `TestimonialCard.tsx`
**Import:** `import { TestimonialCard } from '@scoria/ui'`

Testimonial quote card with serif italic quote, attribution, accent background, and decorative left border.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `quote` | `string` | *required* | Testimonial quote text (rendered in smart quotes) |
| `name` | `string` | *required* | Attribution name |
| `role` | `string` | -- | Optional role/descriptor after name |
| `className` | `string` | -- | Additional CSS classes |

### FAQAccordion -- HH-relevant

**File:** `FAQAccordion.tsx`
**Import:** `import { FAQAccordion } from '@scoria/ui'`

Collapsible question/answer pairs with CSS-animated expand/collapse. Chevron rotates on open.

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `items` | `FAQItem[]` | *required* | Array of `{ question: string, answer: string }` |
| `heading` | `string` | -- | Optional section heading above the accordion |
| `className` | `string` | -- | Additional CSS classes |

---

## Components That DO NOT Exist

These are sometimes referenced in old agent directives but have no source file in `@scoria/ui`. **If the pipeline needs any of these, it must CREATE them.**

| Name | Notes |
|------|-------|
| `Badge` | No badge/chip component exists. Use styled `<span>` or create one. |
| `Separator` | No horizontal rule component. Use `<hr>` with Tailwind classes or create one. |
| `Skeleton` | No loading skeleton. Create if needed for async content. |
| `Avatar` | No avatar component. `DashboardSidebar` and `TaskCard` have inline avatar rendering but no reusable `Avatar` export. |
| `Label` | No form label component. Use native `<label>` with `font-body text-sm`. |
| `Textarea` | No textarea component. Create following the `Input` pattern if needed. |
| `Select` | No select/dropdown component. Create using Radix `Select` if needed. |
| `CourseCard` | No standalone course card. Compose from `Card` sub-components. |
| `FeatureGrid` | No feature grid component. Compose from `Card` in CSS grid layout. |

---

## Updating This File

When the pipeline creates a new component, add it to this registry immediately:

1. Add the component to the appropriate table (Primitives or Domain Components).
2. List all props with types, defaults, and descriptions.
3. If the component was previously listed in "Components That DO NOT Exist", remove it from that table.
4. Note whether it is HH-relevant, PHEDRIS-only, or shared.
