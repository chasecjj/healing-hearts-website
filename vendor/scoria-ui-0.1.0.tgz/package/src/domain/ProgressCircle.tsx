import * as React from 'react'
import { cn } from '../lib/utils'

export interface ProgressCircleProps {
  /** Percentage value 0-100 */
  value: number
  /** Size in pixels */
  size?: number
  /** Stroke width */
  strokeWidth?: number
  /** Optional center content (replaces default percentage display) */
  children?: React.ReactNode
  /** Additional CSS classes */
  className?: string
}

const ProgressCircle = React.forwardRef<HTMLDivElement, ProgressCircleProps>(
  ({ value, size = 192, strokeWidth = 4, children, className }, ref) => {
    const clampedValue = Math.min(100, Math.max(0, value))
    const radius = (size - strokeWidth * 2) / 2
    const circumference = 2 * Math.PI * radius
    const offset = circumference - (clampedValue / 100) * circumference
    const center = size / 2

    return (
      <div
        ref={ref}
        className={cn('relative flex items-center justify-center', className)}
        style={{ width: size, height: size }}
        role="progressbar"
        aria-valuenow={clampedValue}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`${clampedValue}% progress`}
      >
        <svg
          className="absolute inset-0 -rotate-90"
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          fill="none"
          aria-hidden="true"
        >
          {/* Background track */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            className="text-neutral-200"
          />
          {/* Progress arc */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth + 2}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="text-primary transition-all duration-700 ease-out"
          />
        </svg>
        <div className="relative z-10 flex flex-col items-center">
          {children ?? (
            <span className="font-accent text-3xl font-bold text-foreground">
              {clampedValue}%
            </span>
          )}
        </div>
      </div>
    )
  }
)
ProgressCircle.displayName = 'ProgressCircle'

export { ProgressCircle }
