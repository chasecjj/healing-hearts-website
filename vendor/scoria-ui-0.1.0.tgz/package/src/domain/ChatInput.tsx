import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../lib/utils'
import { Button } from '../components/button'

export interface ChatInputProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof chatInputVariants> {
  /** Callback when the user sends a message */
  onSend?: (text: string) => void
  /** Input placeholder text */
  placeholder?: string
  /** Whether the input is disabled (e.g. while waiting for a response) */
  disabled?: boolean
}

const chatInputVariants = cva(
  'flex items-center gap-2 px-4 py-2.5',
  {
    variants: {
      surface: {
        default: 'bg-neutral-100',
        elevated: 'bg-neutral-200',
        inset: 'bg-neutral-50',
      },
    },
    defaultVariants: {
      surface: 'default',
    },
  }
)

const ChatInput = React.forwardRef<HTMLDivElement, ChatInputProps>(
  (
    {
      className,
      onSend,
      placeholder = 'Ask PHEDRIS anything...',
      disabled = false,
      surface,
      ...props
    },
    ref
  ) => {
    const [value, setValue] = React.useState('')
    const inputRef = React.useRef<HTMLInputElement>(null)

    const handleSend = () => {
      const trimmed = value.trim()
      if (!trimmed || disabled) return
      onSend?.(trimmed)
      setValue('')
      inputRef.current?.focus()
    }

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        handleSend()
      }
    }

    return (
      <div
        ref={ref}
        className={cn(chatInputVariants({ surface }), className)}
        {...props}
      >
        <label htmlFor="chat-input" className="sr-only">
          Chat message
        </label>
        <input
          ref={inputRef}
          id="chat-input"
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          className={cn(
            'min-w-0 flex-1 rounded-md border border-neutral-200 bg-neutral-50 px-3 py-2',
            'font-body text-xs text-neutral-800 outline-none',
            'placeholder:text-neutral-400',
            'transition-colors focus:border-primary-500',
            'focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2',
            'disabled:cursor-not-allowed disabled:opacity-50'
          )}
          aria-label="Type a message"
        />
        <Button
          size="icon"
          onClick={handleSend}
          disabled={disabled || !value.trim()}
          aria-label="Send message"
          className="h-8 w-8 shrink-0"
        >
          <svg
            className="h-3.5 w-3.5"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            aria-hidden="true"
          >
            <line x1="22" y1="2" x2="11" y2="13" />
            <polygon points="22 2 15 22 11 13 2 9 22 2" />
          </svg>
        </Button>
      </div>
    )
  }
)
ChatInput.displayName = 'ChatInput'

export { ChatInput, chatInputVariants }
