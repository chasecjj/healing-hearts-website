import * as React from 'react'
import { Button } from '../components/button'
import { cn } from '../lib/utils'

export interface HeroSectionProps {
  headline: string
  subheadline?: string
  ctaText?: string
  ctaHref?: string
  onCtaClick?: () => void
  backgroundVariant?: 'light' | 'dark' | 'gradient'
  align?: 'left' | 'center'
  children?: React.ReactNode
  className?: string
}

const HeroSection = React.forwardRef<HTMLElement, HeroSectionProps>(
  (
    {
      headline,
      subheadline,
      ctaText,
      ctaHref,
      onCtaClick,
      backgroundVariant = 'light',
      align = 'center',
      children,
      className,
    },
    ref
  ) => {
    const bgClasses = {
      light: 'bg-neutral-50 text-neutral-900',
      dark: 'bg-neutral-900 text-white',
      gradient:
        'bg-gradient-to-br from-primary-700 via-primary-500 to-primary-300 text-white',
    }

    const isCenter = align === 'center'
    const isDark = backgroundVariant === 'dark' || backgroundVariant === 'gradient'

    const ctaElement = ctaText ? (
      ctaHref ? (
        <a
          href={ctaHref}
          className={cn(
            'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium font-body transition-colors',
            'h-10 px-8',
            isDark
              ? 'bg-white text-primary-700 hover:bg-neutral-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-primary-600'
              : 'bg-primary-500 text-white hover:bg-primary-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2'
          )}
        >
          {ctaText}
        </a>
      ) : (
        <Button
          size="lg"
          variant={isDark ? 'secondary' : 'default'}
          onClick={onCtaClick}
        >
          {ctaText}
        </Button>
      )
    ) : null

    return (
      <section
        ref={ref}
        aria-labelledby="hero-headline"
        className={cn(
          'w-full px-6 py-16 sm:px-10 sm:py-24',
          bgClasses[backgroundVariant],
          className
        )}
      >
        <div
          className={cn(
            'mx-auto max-w-5xl',
            isCenter
              ? 'flex flex-col items-center text-center'
              : 'flex flex-col gap-8 sm:flex-row sm:items-center sm:justify-between'
          )}
        >
          {/* Text block */}
          <div
            className={cn(
              'flex flex-col gap-4',
              isCenter ? 'items-center max-w-2xl' : 'flex-1 max-w-xl'
            )}
          >
            <h1
              id="hero-headline"
              className="font-heading text-4xl font-bold leading-heading sm:text-5xl"
            >
              {headline}
            </h1>

            {subheadline && (
              <p
                className={cn(
                  'font-body text-lg leading-body',
                  isDark ? 'text-neutral-200' : 'text-neutral-600'
                )}
              >
                {subheadline}
              </p>
            )}

            {ctaElement && (
              <div className={cn('mt-2', isCenter ? 'flex justify-center' : '')}>
                {ctaElement}
              </div>
            )}
          </div>

          {/* Custom children slot — shown beside text on desktop (left-align) or below (center) */}
          {children && (
            <div
              className={cn(
                isCenter ? 'mt-8 w-full' : 'flex-1 mt-8 sm:mt-0'
              )}
            >
              {children}
            </div>
          )}
        </div>
      </section>
    )
  }
)
HeroSection.displayName = 'HeroSection'

export { HeroSection }
