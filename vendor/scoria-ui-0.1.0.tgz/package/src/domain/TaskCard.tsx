import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../lib/utils'
import { Card } from '../components/card'

export interface TaskProject {
  id: number
  name: string
  color: string
}

export interface TaskAssignee {
  email: string
  name: string
  avatar?: string
  initial?: string
  className?: string
}

export interface TaskLabel {
  name: string
  color: string
}

const taskCardVariants = cva(
  'cursor-pointer transition-all duration-150',
  {
    variants: {
      done: {
        true: 'opacity-55',
        false: '',
      },
    },
    defaultVariants: {
      done: false,
    },
  }
)

export type TaskPriority = 'urgent' | 'high' | 'normal' | 'low'
export type TaskStatus = 'todo' | 'in_progress' | 'in_review' | 'done'

export interface TaskCardProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'>,
    VariantProps<typeof taskCardVariants> {
  /** Task title */
  title: string
  /** Task status */
  status: TaskStatus
  /** Task priority */
  priority: TaskPriority
  /** Project this task belongs to */
  project?: TaskProject
  /** Assigned team member */
  assignee?: TaskAssignee
  /** Due date as a display string (e.g. "Mar 26") */
  dueDate?: string | null
  /** Labels/tags on the task */
  labels?: TaskLabel[]
  /** Callback when the card is clicked */
  onCardClick?: () => void
}

const priorityColorMap: Record<TaskPriority, string> = {
  urgent: 'bg-error',
  high: 'bg-warning',
  normal: 'bg-info',
  low: 'bg-neutral-400',
}

const TaskCard = React.forwardRef<HTMLDivElement, TaskCardProps>(
  (
    {
      className,
      title,
      status,
      priority,
      project,
      assignee,
      dueDate,
      labels = [],
      done,
      onCardClick,
      ...props
    },
    ref
  ) => {
    const isDone = done ?? status === 'done'

    return (
      <Card
        ref={ref}
        role="article"
        tabIndex={0}
        onClick={onCardClick}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault()
            onCardClick?.()
          }
        }}
        aria-label={`Task: ${title}${isDone ? ' (completed)' : ''}`}
        className={cn(
          taskCardVariants({ done: isDone }),
          'border-neutral-200 p-3 shadow-sm hover:shadow-md hover:-translate-y-px',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2',
          className
        )}
        {...props}
      >
        {/* Title */}
        <p
          className={cn(
            'mb-2 font-body text-xs font-medium leading-snug text-neutral-800',
            isDone && 'line-through decoration-neutral-400'
          )}
        >
          {title}
        </p>

        {/* Meta row: tags left, assignee/date/priority right */}
        <div className="flex items-center justify-between gap-1.5">
          {/* Labels */}
          <div className="flex flex-wrap gap-1">
            {project && (
              <span
                className="whitespace-nowrap rounded font-mono text-2xs font-semibold tracking-wide px-1.5 py-0.5"
                style={{
                  backgroundColor: `${project.color}18`,
                  color: project.color,
                }}
              >
                {project.name}
              </span>
            )}
            {labels.map((label) => (
              <span
                key={label.name}
                className="whitespace-nowrap rounded font-mono text-2xs font-semibold tracking-wide px-1.5 py-0.5"
                style={{
                  backgroundColor: `${label.color}18`,
                  color: label.color,
                }}
              >
                {label.name}
              </span>
            ))}
          </div>

          {/* Right side: assignee avatar, due date, priority dot */}
          <div className="flex shrink-0 items-center gap-1.5">
            {assignee && (
              assignee.avatar ? (
                <img
                  src={assignee.avatar}
                  alt={assignee.name}
                  className="h-5 w-5 rounded-full object-cover"
                />
              ) : (
                <div
                  className={cn(
                    'flex h-5 w-5 items-center justify-center rounded-full',
                    'font-body text-2xs font-semibold text-white',
                    assignee.className ?? 'bg-primary-500'
                  )}
                  aria-label={assignee.name}
                >
                  {assignee.initial ?? assignee.name.charAt(0)}
                </div>
              )
            )}
            {dueDate && (
              <span className="whitespace-nowrap font-mono text-2xs text-neutral-400">
                {dueDate}
              </span>
            )}
            <span
              className={cn(
                'h-1.5 w-1.5 shrink-0 rounded-full',
                priorityColorMap[priority]
              )}
              aria-label={`Priority: ${priority}`}
            />
          </div>
        </div>
      </Card>
    )
  }
)
TaskCard.displayName = 'TaskCard'

export { TaskCard, taskCardVariants }
