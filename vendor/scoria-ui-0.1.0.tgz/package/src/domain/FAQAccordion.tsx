import * as React from 'react'
import { cn } from '../lib/utils'

export interface FAQItem {
  question: string
  answer: string
}

export interface FAQAccordionProps extends React.HTMLAttributes<HTMLElement> {
  items: FAQItem[]
  heading?: string
}

function AccordionItem({ question, answer }: FAQItem) {
  const [open, setOpen] = React.useState(false)
  const contentRef = React.useRef<HTMLDivElement>(null)

  return (
    <div className="border-b border-neutral-200">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        aria-expanded={open}
        className="flex w-full items-center justify-between py-5 text-left font-heading text-base font-semibold text-neutral-800 transition-colors duration-200 hover:text-primary-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2 sm:text-lg"
      >
        <span>{question}</span>
        <svg
          className={cn(
            'ml-4 h-5 w-5 flex-shrink-0 text-neutral-400 transition-transform duration-200',
            open && 'rotate-180 text-primary-500'
          )}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          aria-hidden="true"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      <div
        ref={contentRef}
        className="overflow-hidden transition-[max-height] duration-300 ease-out"
        style={{ maxHeight: open ? contentRef.current?.scrollHeight : 0 }}
      >
        <p className="pb-5 font-body text-base leading-body text-neutral-600">
          {answer}
        </p>
      </div>
    </div>
  )
}

const FAQAccordion = React.forwardRef<HTMLElement, FAQAccordionProps>(
  ({ className, items, heading, ...props }, ref) => {
    return (
      <section
        ref={ref}
        className={cn('mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8', className)}
        {...props}
      >
        {heading && (
          <h2 className="mb-8 font-heading text-3xl font-bold tracking-tight text-neutral-800 sm:text-4xl">
            {heading}
          </h2>
        )}
        <div className="divide-y divide-neutral-200 rounded-2xl border border-neutral-200 bg-neutral-50 px-6 shadow-[0_4px_20px_-4px_rgba(7,58,71,0.08)]">
          {items.map((item, index) => (
            <AccordionItem key={index} question={item.question} answer={item.answer} />
          ))}
        </div>
      </section>
    )
  }
)
FAQAccordion.displayName = 'FAQAccordion'

export { FAQAccordion }
