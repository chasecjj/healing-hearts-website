import * as React from 'react'
import { cn } from '../lib/utils'

export interface TimelineLesson {
  id: string
  /** Display label (e.g. "7.1") */
  label: string
  title: string
  status: 'completed' | 'in-progress' | 'locked'
}

export interface JourneyTimelineProps {
  lessons: TimelineLesson[]
  /** Called when a non-locked lesson is clicked */
  onLessonClick?: (lessonId: string) => void
  /** Additional CSS classes */
  className?: string
}

// Inline SVG icons to avoid external dependencies
const CheckIcon = () => (
  <svg
    aria-hidden="true"
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    className="shrink-0"
  >
    <path
      d="M13 4L6 11L3 8"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)

const PlayIcon = () => (
  <svg
    aria-hidden="true"
    width="14"
    height="14"
    viewBox="0 0 14 14"
    fill="none"
    className="shrink-0"
  >
    <path d="M4 2L12 7L4 12V2Z" fill="currentColor" />
  </svg>
)

const LockIcon = () => (
  <svg
    aria-hidden="true"
    width="14"
    height="14"
    viewBox="0 0 14 14"
    fill="none"
    className="shrink-0"
  >
    <rect x="3" y="6" width="8" height="6" rx="1" stroke="currentColor" strokeWidth="1.5" />
    <path
      d="M5 6V4C5 2.89543 5.89543 2 7 2C8.10457 2 9 2.89543 9 4V6"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
)

const statusConfig = {
  completed: {
    icon: CheckIcon,
    dotClass: 'bg-primary/10 text-primary',
    labelClass: 'text-primary font-bold',
    badge: 'Completed',
    badgeClass: 'text-primary',
    rowClass: 'bg-white hover:bg-neutral-50 hover:shadow-sm cursor-pointer',
    borderClass: '',
  },
  'in-progress': {
    icon: PlayIcon,
    dotClass: 'bg-primary text-white',
    labelClass: 'text-primary font-bold',
    badge: 'In Progress',
    badgeClass: 'text-accent',
    rowClass: 'bg-white border-l-4 border-primary hover:bg-neutral-50 cursor-pointer',
    borderClass: '',
  },
  locked: {
    icon: LockIcon,
    dotClass: 'bg-neutral-200 text-neutral-400',
    labelClass: 'text-neutral-400',
    badge: null,
    badgeClass: '',
    rowClass: 'bg-neutral-50/50 opacity-60 cursor-not-allowed',
    borderClass: '',
  },
}

const JourneyTimeline = React.forwardRef<HTMLDivElement, JourneyTimelineProps>(
  ({ lessons, onLessonClick, className }, ref) => {
    return (
      <div ref={ref} className={cn('space-y-3', className)} role="list" aria-label="Learning journey">
        {lessons.map((lesson) => {
          const config = statusConfig[lesson.status]
          const IconComponent = config.icon
          const isClickable = lesson.status !== 'locked'

          return (
            <div
              key={lesson.id}
              role="listitem"
              className={cn(
                'relative flex items-center gap-5 p-5 rounded-2xl transition-all',
                config.rowClass
              )}
              onClick={() => isClickable && onLessonClick?.(lesson.id)}
              onKeyDown={(e) => {
                if (isClickable && (e.key === 'Enter' || e.key === ' ')) {
                  e.preventDefault()
                  onLessonClick?.(lesson.id)
                }
              }}
              tabIndex={isClickable ? 0 : -1}
              aria-label={`${lesson.title}${config.badge ? ` - ${config.badge}` : ''}`}
            >
              {/* Status icon circle */}
              <div
                className={cn(
                  'flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center',
                  config.dotClass
                )}
                aria-hidden="true"
              >
                <IconComponent />
              </div>

              {/* Lesson info */}
              <div className="flex-grow min-w-0">
                <span
                  className={cn(
                    'text-[10px] font-heading uppercase tracking-widest block',
                    config.labelClass
                  )}
                >
                  Lesson {lesson.label}
                </span>
                <h3 className="font-body text-lg font-semibold text-neutral-900 truncate">
                  {lesson.title}
                </h3>
              </div>

              {/* Status badge */}
              {config.badge && (
                <span
                  className={cn(
                    'text-xs font-heading font-bold flex-shrink-0',
                    config.badgeClass
                  )}
                >
                  {config.badge}
                </span>
              )}
            </div>
          )
        })}
      </div>
    )
  }
)
JourneyTimeline.displayName = 'JourneyTimeline'

export { JourneyTimeline }
