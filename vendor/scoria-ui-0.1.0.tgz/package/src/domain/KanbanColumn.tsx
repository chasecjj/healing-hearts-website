import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../lib/utils'

export interface KanbanColumnProps extends React.HTMLAttributes<HTMLDivElement>,
  VariantProps<typeof kanbanColumnVariants> {
  /** Column title (e.g. "To Do", "In Progress") */
  title: string
  /** Status key this column represents */
  status: string
  /** Number of tasks in the column */
  count?: number
  /** Dot color — accepts any CSS color string or Tailwind class */
  dotColor?: string
  /** Whether dotColor is a CSS color value (true) or a Tailwind class (false) */
  dotColorIsCSS?: boolean
  /** Column content — typically TaskCard components */
  children?: React.ReactNode
}

const kanbanColumnVariants = cva(
  'flex flex-col gap-2 overflow-hidden',
  {
    variants: {
      size: {
        default: 'min-w-[140px] flex-1',
        fixed: 'w-[220px] shrink-0',
      },
    },
    defaultVariants: {
      size: 'default',
    },
  }
)

const KanbanColumn = React.forwardRef<HTMLDivElement, KanbanColumnProps>(
  (
    {
      className,
      title,
      status,
      count,
      dotColor = 'bg-neutral-400',
      dotColorIsCSS = false,
      size,
      children,
      ...props
    },
    ref
  ) => {
    const childCount = count ?? React.Children.count(children)

    return (
      <div
        ref={ref}
        className={cn(kanbanColumnVariants({ size }), className)}
        role="region"
        aria-label={`${title} column, ${childCount} tasks`}
        data-status={status}
        {...props}
      >
        {/* Column Header */}
        <div className="mb-1 flex shrink-0 items-center gap-1.5 py-1">
          <span
            className={cn(
              'h-1.5 w-1.5 shrink-0 rounded-full',
              !dotColorIsCSS && dotColor
            )}
            style={dotColorIsCSS ? { backgroundColor: dotColor } : undefined}
            aria-hidden="true"
          />
          <span className="font-body text-xs font-semibold uppercase tracking-wider text-neutral-500">
            {title}
          </span>
          <span className="rounded-full bg-neutral-100 px-1.5 font-mono text-2xs text-neutral-400">
            {childCount}
          </span>
        </div>

        {/* Card List */}
        <div
          className={cn(
            'flex flex-1 flex-col gap-2 overflow-y-auto pr-1',
            'scrollbar-thin scrollbar-thumb-neutral-200'
          )}
          role="list"
          aria-label={`${title} tasks`}
        >
          {React.Children.map(children, (child) => (
            <div role="listitem">{child}</div>
          ))}
        </div>
      </div>
    )
  }
)
KanbanColumn.displayName = 'KanbanColumn'

export { KanbanColumn, kanbanColumnVariants }
