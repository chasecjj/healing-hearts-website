import * as React from 'react'
import {
  Card,
  CardHeader,
  CardDescription,
  CardContent,
  CardFooter,
} from '../components/card'
import { Button } from '../components/button'
import { cn } from '../lib/utils'

export interface PricingCardProps {
  planName: string
  price: string
  period?: string
  description?: string
  features: string[]
  ctaText?: string
  ctaHref?: string
  onCtaClick?: () => void
  highlighted?: boolean
  className?: string
}

const CheckIcon = () => (
  <svg
    aria-hidden="true"
    focusable="false"
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="shrink-0 text-primary-500"
  >
    <path
      d="M13.5 4L6 11.5L2.5 8"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)

const PricingCard = React.forwardRef<HTMLDivElement, PricingCardProps>(
  (
    {
      planName,
      price,
      period,
      description,
      features,
      ctaText,
      ctaHref,
      onCtaClick,
      highlighted = false,
      className,
    },
    ref
  ) => {
    const ctaElement = ctaText ? (
      ctaHref ? (
        <a
          href={ctaHref}
          className={cn(
            'inline-flex w-full items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium font-body transition-colors h-9 px-4 py-2',
            highlighted
              ? 'bg-primary-500 text-white hover:bg-primary-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2'
              : 'border border-neutral-200 bg-white text-neutral-900 hover:bg-neutral-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2'
          )}
          aria-label={`${ctaText} — ${planName} plan`}
        >
          {ctaText}
        </a>
      ) : (
        <Button
          variant={highlighted ? 'default' : 'outline'}
          className="w-full"
          onClick={onCtaClick}
          aria-label={`${ctaText} — ${planName} plan`}
        >
          {ctaText}
        </Button>
      )
    ) : null

    return (
      <Card
        ref={ref}
        className={cn(
          'flex flex-col transition-shadow',
          highlighted &&
            'border-2 border-primary-500 shadow-lg shadow-primary-500/20',
          className
        )}
        aria-label={`${planName} pricing plan`}
      >
        {highlighted && (
          <div
            className="rounded-t-md bg-primary-500 px-6 py-1.5 text-center text-xs font-semibold font-body uppercase tracking-wide text-white"
            aria-label="Recommended plan"
          >
            Recommended
          </div>
        )}

        <CardHeader>
          <h3 className="font-heading leading-heading text-xl font-semibold text-neutral-900">
            {planName}
          </h3>
          <div className="flex items-baseline gap-1 pt-1" aria-label={`Price: ${price}${period ?? ''}`}>
            <span className="font-heading text-4xl font-bold text-neutral-900">
              {price}
            </span>
            {period && (
              <span className="font-body text-sm text-neutral-500">{period}</span>
            )}
          </div>
          {description && (
            <CardDescription>{description}</CardDescription>
          )}
        </CardHeader>

        <CardContent className="flex-1">
          <ul
            className="flex flex-col gap-2"
            aria-label={`Features included in ${planName} plan`}
          >
            {features.map((feature) => (
              <li
                key={feature}
                className="flex items-start gap-2 font-body text-sm text-neutral-700"
              >
                <CheckIcon />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </CardContent>

        {ctaElement && (
          <CardFooter className="pt-2">
            {ctaElement}
          </CardFooter>
        )}
      </Card>
    )
  }
)
PricingCard.displayName = 'PricingCard'

export { PricingCard }
