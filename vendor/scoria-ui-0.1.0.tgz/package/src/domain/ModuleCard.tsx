import * as React from 'react'
import { cn } from '../lib/utils'

export interface ModuleCardProps {
  /** Module title */
  title: string
  /** Module description */
  description: string
  /** Category label badge (e.g. "Foundation", "Advanced Healing") */
  category?: string
  /** Number of lessons or modules */
  lessonCount?: number
  /** Image URL for the card */
  imageUrl?: string
  /** Image alt text */
  imageAlt?: string
  /** Progress percentage 0-100 (omit to hide progress) */
  progress?: number
  /** Whether this module is locked */
  locked?: boolean
  /** Click handler */
  onClick?: () => void
  /** Additional CSS classes */
  className?: string
}

const ModuleCard = React.forwardRef<HTMLDivElement, ModuleCardProps>(
  (
    {
      title,
      description,
      category,
      lessonCount,
      imageUrl,
      imageAlt = '',
      progress,
      locked = false,
      onClick,
      className,
    },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={cn(
          'group bg-white rounded-2xl overflow-hidden shadow-[0_4px_20px_-4px_rgba(7,58,71,0.08)]',
          'transition-all duration-200',
          !locked && onClick && 'cursor-pointer hover:shadow-[0_8px_30px_-4px_rgba(7,58,71,0.12)] hover:scale-[1.02]',
          locked && 'opacity-60',
          className
        )}
        onClick={!locked ? onClick : undefined}
        onKeyDown={(e) => {
          if (!locked && onClick && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault()
            onClick()
          }
        }}
        tabIndex={!locked && onClick ? 0 : -1}
        role={onClick ? 'button' : undefined}
        aria-label={`${title}${locked ? ' - Locked' : ''}`}
      >
        {/* Image */}
        {imageUrl && (
          <div className="h-48 overflow-hidden relative">
            <img
              src={imageUrl}
              alt={imageAlt}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            {category && (
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-heading font-bold uppercase tracking-wider">
                {category}
              </div>
            )}
            {locked && (
              <div className="absolute inset-0 bg-neutral-900/20 flex items-center justify-center">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  className="text-white"
                  aria-hidden="true"
                >
                  <rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="2" />
                  <path d="M8 10V7C8 4.79 9.79 3 12 3C14.21 3 16 4.79 16 7V10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
            )}
          </div>
        )}

        {/* Content */}
        <div className="p-6">
          {!imageUrl && category && (
            <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-[10px] font-heading font-bold uppercase tracking-wider mb-3">
              {category}
            </span>
          )}
          <h3 className="font-heading text-xl font-semibold mb-3 group-hover:text-primary transition-colors">
            {title}
          </h3>
          <p className="text-sm text-neutral-500 mb-4 line-clamp-2 leading-relaxed">
            {description}
          </p>

          {/* Progress bar (if applicable) */}
          {typeof progress === 'number' && progress > 0 && (
            <div className="mb-4">
              <div className="flex justify-between text-xs text-neutral-400 mb-1">
                <span>Progress</span>
                <span>{progress}%</span>
              </div>
              <div className="h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="flex items-center justify-between">
            {typeof lessonCount === 'number' && (
              <span className="text-xs text-neutral-400">
                {lessonCount} {lessonCount === 1 ? 'Lesson' : 'Lessons'}
              </span>
            )}
          </div>
        </div>
      </div>
    )
  }
)
ModuleCard.displayName = 'ModuleCard'

export { ModuleCard }
