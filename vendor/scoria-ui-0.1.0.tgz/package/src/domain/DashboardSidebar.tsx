import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../lib/utils'

export interface NavItem {
  id: string
  label: string
  icon: React.ReactNode
}

export interface TeamMember {
  id: string
  name: string
  initial: string
  online?: boolean
  className?: string
}

export interface DashboardSidebarProps
  extends React.HTMLAttributes<HTMLElement>,
    VariantProps<typeof dashboardSidebarVariants> {
  /** Currently active nav item id */
  activeItem?: string
  /** Navigation items to render */
  navItems: NavItem[]
  /** Team members displayed at the bottom */
  teamMembers?: TeamMember[]
  /** Whether the sidebar is collapsed (icon-only) or expanded */
  collapsed?: boolean
  /** Callback when a nav item is clicked */
  onNavClick?: (id: string) => void
  /** Callback when a team avatar is clicked */
  onTeamClick?: (id: string) => void
  /** Logo content — defaults to "P" */
  logo?: React.ReactNode
}

const dashboardSidebarVariants = cva(
  'flex flex-col py-3 transition-[width,min-width] duration-200',
  {
    variants: {
      surface: {
        default: 'bg-[var(--sidebar-bg,theme(colors.neutral.100))]',
        elevated: 'bg-[var(--sidebar-bg,theme(colors.neutral.200))]',
        inset: 'bg-[var(--sidebar-bg,theme(colors.neutral.50))]',
      },
    },
    defaultVariants: {
      surface: 'default',
    },
  }
)

const DashboardSidebar = React.forwardRef<HTMLElement, DashboardSidebarProps>(
  (
    {
      className,
      activeItem,
      navItems,
      teamMembers = [],
      collapsed = true,
      onNavClick,
      onTeamClick,
      logo = 'P',
      surface,
      ...props
    },
    ref
  ) => {
    return (
      <nav
        ref={ref}
        className={cn(
          dashboardSidebarVariants({ surface }),
          collapsed ? 'w-[60px] min-w-[60px]' : 'w-[200px] min-w-[200px]',
          className
        )}
        aria-label="Main navigation"
        {...props}
      >
        {/* Logo */}
        <div className="mb-2 flex justify-center">
          <div
            className={cn(
              'flex h-8 w-8 items-center justify-center rounded-lg',
              'bg-gradient-to-br from-primary-500 to-primary-600',
              'font-mono text-base font-bold text-white',
              'shadow-md'
            )}
          >
            {logo}
          </div>
        </div>

        {/* Nav Items */}
        <div className="flex flex-1 flex-col gap-0.5 px-2">
          {navItems.map((item) => {
            const isActive = activeItem === item.id
            return (
              <button
                key={item.id}
                onClick={() => onNavClick?.(item.id)}
                aria-label={item.label}
                aria-current={isActive ? 'page' : undefined}
                className={cn(
                  'group relative flex h-10 items-center justify-center rounded-md',
                  'cursor-pointer transition-colors duration-150',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2',
                  isActive
                    ? 'bg-primary-500/10 text-primary-500'
                    : 'text-neutral-400 hover:bg-primary-500/5 hover:text-neutral-600',
                  !collapsed && 'justify-start gap-3 px-3'
                )}
              >
                {/* Active indicator */}
                {isActive && (
                  <span
                    className="absolute left-0 top-2 bottom-2 w-[3px] rounded-r-sm bg-primary-500"
                    aria-hidden="true"
                  />
                )}

                {/* Icon */}
                <span className="flex h-5 w-5 shrink-0 items-center justify-center [&_svg]:h-5 [&_svg]:w-5" aria-hidden="true">
                  {item.icon}
                </span>

                {/* Label — visible when expanded, tooltip when collapsed */}
                {!collapsed && (
                  <span className="font-body text-sm font-medium">{item.label}</span>
                )}
                {collapsed && (
                  <span
                    role="tooltip"
                    className={cn(
                      'pointer-events-none absolute left-[52px] top-1/2 -translate-y-1/2',
                      'whitespace-nowrap rounded bg-neutral-800 px-2.5 py-1',
                      'text-xs font-medium text-white',
                      'opacity-0 transition-opacity group-hover:opacity-100',
                      'z-50'
                    )}
                  >
                    {item.label}
                  </span>
                )}
              </button>
            )
          })}
        </div>

        {/* Divider */}
        {teamMembers.length > 0 && (
          <div className="mx-auto my-2 h-px w-7 bg-neutral-200" aria-hidden="true" />
        )}

        {/* Team Avatars */}
        <div className="flex flex-col items-center gap-1.5 px-2 pb-1">
          {teamMembers.map((member) => (
            <button
              key={member.id}
              onClick={() => onTeamClick?.(member.id)}
              aria-label={member.name}
              className={cn(
                'group relative flex h-7 w-7 items-center justify-center rounded-full',
                'font-body text-2xs font-semibold text-white',
                'cursor-pointer transition-transform hover:scale-110',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2',
                member.className
              )}
            >
              {member.initial}

              {/* Online indicator */}
              {member.online && (
                <span
                  className="absolute bottom-0 right-0 h-2 w-2 rounded-full border-2 border-white bg-success"
                  aria-label="Online"
                />
              )}

              {/* Tooltip */}
              {collapsed && (
                <span
                  role="tooltip"
                  className={cn(
                    'pointer-events-none absolute left-10 top-1/2 -translate-y-1/2',
                    'whitespace-nowrap rounded bg-neutral-800 px-2.5 py-1',
                    'text-xs font-medium text-white',
                    'opacity-0 transition-opacity group-hover:opacity-100',
                    'z-50'
                  )}
                >
                  {member.name}
                </span>
              )}
            </button>
          ))}
        </div>
      </nav>
    )
  }
)
DashboardSidebar.displayName = 'DashboardSidebar'

export { DashboardSidebar, dashboardSidebarVariants }
