import * as React from 'react'
import { cn } from '../lib/utils'

export interface OrganicDividerProps {
  /** Which predefined wave shape to use */
  variant?: 'wave-1' | 'wave-2' | 'wave-3'
  /** Fill color — Tailwind text color class applied to the SVG (uses currentColor) */
  fillClass?: string
  /** Flip vertically — useful for top-of-section dividers */
  flip?: boolean
  /** Additional CSS classes on the wrapper */
  className?: string
}

const PATHS: Record<string, string> = {
  'wave-1':
    'M0,192L48,176C96,160,192,128,288,128C384,128,480,160,576,181.3C672,203,768,213,864,197.3C960,181,1056,139,1152,122.7C1248,107,1344,117,1392,122.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z',
  'wave-2':
    'M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z',
  'wave-3':
    'M0,96L60,112C120,128,240,160,360,154.7C480,149,600,107,720,90.7C840,75,960,85,1080,101.3C1200,117,1320,139,1380,149.3L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z',
}

const VIEWBOXES: Record<string, string> = {
  'wave-1': '0 0 1440 320',
  'wave-2': '0 0 1440 120',
  'wave-3': '0 0 1440 320',
}

/**
 * Decorative SVG wave divider for organic section transitions.
 * Place between sections to replace hard colour boundaries with a flowing curve.
 *
 * Usage:
 * ```jsx
 * <OrganicDivider variant="wave-1" fillClass="text-neutral-50" />
 * ```
 *
 * The `fillClass` should match the *next* section's background colour so the
 * wave blends seamlessly.
 */
const OrganicDivider = React.forwardRef<HTMLDivElement, OrganicDividerProps>(
  ({ variant = 'wave-1', fillClass = 'text-neutral-50', flip = false, className }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'w-full leading-[0] pointer-events-none select-none',
          flip && 'rotate-180',
          fillClass,
          className
        )}
        aria-hidden="true"
      >
        <svg
          viewBox={VIEWBOXES[variant]}
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          className="w-full h-auto block"
        >
          <path d={PATHS[variant]} fill="currentColor" />
        </svg>
      </div>
    )
  }
)
OrganicDivider.displayName = 'OrganicDivider'

export { OrganicDivider }
