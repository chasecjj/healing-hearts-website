import * as React from 'react'
import { cn } from '../lib/utils'

export interface ActivityProjectTag {
  name: string
  color: string
}

export interface ActivityItemProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Icon content — emoji string or React node */
  icon: React.ReactNode
  /** Icon background className (e.g. Tailwind bg class) */
  iconClassName?: string
  /** Activity description — can contain inline <b> or <strong> via React nodes */
  text: React.ReactNode
  /** Display timestamp (e.g. "2 min ago") */
  timestamp: string
  /** Optional project tag */
  projectTag?: ActivityProjectTag
}

const ActivityItem = React.forwardRef<HTMLDivElement, ActivityItemProps>(
  (
    {
      className,
      icon,
      iconClassName,
      text,
      timestamp,
      projectTag,
      ...props
    },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={cn(
          'flex gap-2.5 rounded-md p-3 shadow-sm transition-shadow hover:shadow-md',
          'bg-neutral-50 last:mb-0',
          className
        )}
        role="article"
        {...props}
      >
        {/* Icon */}
        <div
          className={cn(
            'flex h-7 w-7 shrink-0 items-center justify-center rounded-md',
            'text-sm',
            iconClassName ?? 'bg-neutral-100'
          )}
          aria-hidden="true"
        >
          {icon}
        </div>

        {/* Content */}
        <div className="min-w-0 flex-1">
          <p className="font-body text-xs leading-snug text-neutral-600 [&_b]:font-medium [&_b]:text-neutral-800 [&_strong]:font-medium [&_strong]:text-neutral-800">
            {text}
          </p>
          <div className="mt-0.5 flex items-center gap-2">
            <span className="font-mono text-2xs text-neutral-400">
              {timestamp}
            </span>
            {projectTag && (
              <span
                className="whitespace-nowrap rounded font-mono text-2xs font-semibold tracking-wide px-1.5 py-0.5"
                style={{
                  backgroundColor: `${projectTag.color}18`,
                  color: projectTag.color,
                }}
              >
                {projectTag.name}
              </span>
            )}
          </div>
        </div>
      </div>
    )
  }
)
ActivityItem.displayName = 'ActivityItem'

export { ActivityItem }
