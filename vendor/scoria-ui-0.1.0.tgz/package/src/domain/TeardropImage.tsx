import * as React from 'react'
import { cn } from '../lib/utils'

export interface TeardropImageProps {
  src: string
  alt: string
  /** Overlay tint color — Tailwind bg class (e.g., 'bg-primary/10') */
  overlayClass?: string
  /** Additional CSS classes on the outer container */
  className?: string
  /** Inline styles applied to the inner img element (e.g., objectPosition) */
  imgStyle?: React.CSSProperties
}

/**
 * An image clipped inside an organic teardrop / leaf shape using an inline SVG
 * mask. The shape is wider at the bottom and tapers to a point at the top,
 * evoking a botanical / sanctuary feel.
 *
 * On screens narrower than md, the mask is replaced with a simple rounded
 * rectangle for visual clarity at small sizes.
 *
 * The SVG mask path is derived from the Stitch "Organic Flow" export.
 */
const TeardropImage = React.forwardRef<HTMLDivElement, TeardropImageProps>(
  ({ src, alt, overlayClass, className, imgStyle }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'relative aspect-[3/4] w-full max-w-md mx-auto',
          className
        )}
      >
        {/* Hidden SVG that defines the mask */}
        <svg
          className="absolute w-0 h-0"
          aria-hidden="true"
        >
          <defs>
            <clipPath id="teardrop-mask" clipPathUnits="objectBoundingBox">
              {/* Normalised 0..1 teardrop: pointy top, round bottom */}
              <path d="M0.5 0 C0.7 0.2 0.9 0.4 0.9 0.7 C0.9 0.9 0.7 1 0.5 1 C0.3 1 0.1 0.9 0.1 0.7 C0.1 0.4 0.3 0.2 0.5 0" />
            </clipPath>
          </defs>
        </svg>

        {/* Mobile: rounded rectangle. md+: teardrop clip */}
        <div
          className={cn(
            'w-full h-full overflow-hidden rounded-[2.5rem]',
            'md:rounded-none'
          )}
          style={{
            WebkitClipPath: undefined,
            clipPath: undefined,
          }}
        >
          <div
            className="w-full h-full md:[clip-path:url(#teardrop-mask)] rounded-[2.5rem] md:rounded-none overflow-hidden"
          >
            <img
              src={src}
              alt={alt}
              className="w-full h-full object-cover"
              style={imgStyle}
              loading="lazy"
            />
          </div>
        </div>

        {overlayClass && (
          <div
            className={cn(
              'absolute inset-0 mix-blend-overlay pointer-events-none',
              'md:[clip-path:url(#teardrop-mask)]',
              overlayClass
            )}
          />
        )}
      </div>
    )
  }
)
TeardropImage.displayName = 'TeardropImage'

export { TeardropImage }
