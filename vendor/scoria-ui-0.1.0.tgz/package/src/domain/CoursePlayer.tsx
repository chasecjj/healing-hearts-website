import * as React from 'react'
import { Button } from '../components/button'
import { cn } from '../lib/utils'

export interface CourseLesson {
  id: string
  title: string
  completed?: boolean
}

export interface CourseModule {
  id: string
  title: string
  lessons: CourseLesson[]
}

export interface CoursePlayerProps {
  modules: CourseModule[]
  currentLessonId?: string
  onLessonSelect?: (lessonId: string) => void
  sidebarOpen?: boolean
  onSidebarToggle?: () => void
  children: React.ReactNode
  className?: string
}

// Simple check SVG — no external dependency
const CheckIcon = () => (
  <svg
    aria-hidden="true"
    focusable="false"
    width="14"
    height="14"
    viewBox="0 0 14 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="shrink-0"
  >
    <path
      d="M11.5 3.5L5.5 9.5L2.5 6.5"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)

// Hamburger / close icon for sidebar toggle
const MenuIcon = ({ open }: { open: boolean }) =>
  open ? (
    <svg
      aria-hidden="true"
      focusable="false"
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4 4L16 16M16 4L4 16"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </svg>
  ) : (
    <svg
      aria-hidden="true"
      focusable="false"
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3 5H17M3 10H17M3 15H17"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </svg>
  )

const CoursePlayer = React.forwardRef<HTMLDivElement, CoursePlayerProps>(
  (
    {
      modules,
      currentLessonId,
      onLessonSelect,
      sidebarOpen = true,
      onSidebarToggle,
      children,
      className,
    },
    ref
  ) => {
    // Track internal open state for mobile overlay; controlled externally via sidebarOpen
    const [internalOpen, setInternalOpen] = React.useState(sidebarOpen)

    React.useEffect(() => {
      setInternalOpen(sidebarOpen)
    }, [sidebarOpen])

    const handleToggle = () => {
      if (onSidebarToggle) {
        onSidebarToggle()
      } else {
        setInternalOpen((prev) => !prev)
      }
    }

    const isOpen = onSidebarToggle ? sidebarOpen : internalOpen

    const handleLessonKeyDown = (
      e: React.KeyboardEvent<HTMLButtonElement>,
      lessonId: string
    ) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault()
        onLessonSelect?.(lessonId)
      }
    }

    return (
      <div
        ref={ref}
        className={cn('relative flex h-full min-h-0 w-full overflow-hidden', className)}
      >
        {/* Mobile overlay backdrop */}
        {isOpen && (
          <div
            className="fixed inset-0 z-20 bg-neutral-900/50 sm:hidden"
            aria-hidden="true"
            onClick={handleToggle}
          />
        )}

        {/* Sidebar navigation */}
        <nav
          id="course-sidebar"
          aria-label="Course navigation"
          className={cn(
            // Base
            'flex flex-col bg-neutral-100 overflow-y-auto',
            // Desktop: always visible, fixed width
            'sm:static sm:w-72 sm:translate-x-0 sm:z-auto sm:flex',
            // Mobile: overlay, slides in/out
            'fixed inset-y-0 left-0 z-30 w-72 transition-transform duration-200 ease-in-out',
            isOpen ? 'translate-x-0' : '-translate-x-full sm:translate-x-0'
          )}
        >
          {/* Sidebar header */}
          <div className="flex items-center justify-between bg-neutral-200 px-4 py-4">
            <h2 className="font-heading text-base font-semibold text-neutral-900">
              Course Contents
            </h2>
            {/* Close button — mobile only */}
            <Button
              variant="ghost"
              size="icon"
              className="sm:hidden"
              onClick={handleToggle}
              aria-label="Close course navigation"
              aria-controls="course-sidebar"
            >
              <MenuIcon open={true} />
            </Button>
          </div>

          {/* Module + lesson list */}
          <ol className="flex flex-col py-2" aria-label="Course modules">
            {modules.map((module, moduleIndex) => (
              <li key={module.id} className="flex flex-col">
                {/* Module heading */}
                <div
                  className="px-4 py-2 font-heading text-xs font-semibold uppercase tracking-wider text-neutral-500"
                  id={`module-heading-${module.id}`}
                  aria-label={`Module ${moduleIndex + 1}: ${module.title}`}
                >
                  {module.title}
                </div>

                {/* Lessons */}
                <ol
                  aria-labelledby={`module-heading-${module.id}`}
                  className="flex flex-col"
                >
                  {module.lessons.map((lesson) => {
                    const isCurrent = lesson.id === currentLessonId
                    return (
                      <li key={lesson.id}>
                        <button
                          type="button"
                          onClick={() => onLessonSelect?.(lesson.id)}
                          onKeyDown={(e) => handleLessonKeyDown(e, lesson.id)}
                          aria-current={isCurrent ? 'page' : undefined}
                          aria-label={`${lesson.title}${lesson.completed ? ' — completed' : ''}`}
                          className={cn(
                            'flex w-full items-center gap-3 px-4 py-2.5 text-left font-body text-sm transition-colors',
                            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary-500',
                            isCurrent
                              ? 'bg-primary-50 text-primary-700 font-medium'
                              : 'text-neutral-700 hover:bg-neutral-50 hover:text-neutral-900'
                          )}
                        >
                          {/* Completed indicator */}
                          <span
                            className={cn(
                              'flex h-5 w-5 shrink-0 items-center justify-center rounded-full border',
                              lesson.completed
                                ? 'border-primary-500 bg-primary-500 text-white'
                                : isCurrent
                                ? 'border-primary-500 bg-white text-primary-500'
                                : 'border-neutral-300 bg-white text-transparent'
                            )}
                            aria-hidden="true"
                          >
                            {(lesson.completed || isCurrent) && <CheckIcon />}
                          </span>
                          <span className="flex-1 leading-snug">{lesson.title}</span>
                        </button>
                      </li>
                    )
                  })}
                </ol>
              </li>
            ))}
          </ol>
        </nav>

        {/* Main content area */}
        <div className="flex flex-1 flex-col min-w-0 overflow-auto">
          {/* Top bar — mobile toggle */}
          <div className="flex items-center gap-3 bg-neutral-100 px-4 py-3 sm:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleToggle}
              aria-label="Open course navigation"
              aria-controls="course-sidebar"
              aria-expanded={isOpen}
            >
              <MenuIcon open={false} />
            </Button>
            <span className="font-body text-sm text-neutral-600">Course Navigation</span>
          </div>

          {/* Lesson content */}
          <main
            id="lesson-content"
            aria-label="Lesson content"
            className="flex-1 p-6 sm:p-8"
          >
            {children}
          </main>
        </div>
      </div>
    )
  }
)
CoursePlayer.displayName = 'CoursePlayer'

export { CoursePlayer }
