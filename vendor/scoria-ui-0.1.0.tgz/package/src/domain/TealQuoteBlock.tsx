import * as React from 'react'
import { cn } from '../lib/utils'

export interface TealQuoteBlockProps {
  /** The quote text (rendered in serif italic) */
  quote: string
  /** Attribution line (e.g., "— Elena & Julian, Year 12") */
  attribution?: string
  /** Additional CSS classes on the outer section */
  className?: string
}

/**
 * Full-width section with a teal gradient background and a large, centred
 * serif-italic quotation. Used as a mid-page emotional beat in the
 * Healing Hearts "Organic Flow" layout.
 *
 * Pairs with `OrganicDivider` components placed above and below to create
 * smooth curved transitions into and out of the teal band.
 */
const TealQuoteBlock = React.forwardRef<HTMLElement, TealQuoteBlockProps>(
  ({ quote, attribution, className }, ref) => {
    return (
      <section
        ref={ref}
        className={cn(
          'relative py-24 md:py-32 overflow-hidden',
          'bg-gradient-to-br from-primary-700 via-primary-600 to-primary-500',
          className
        )}
      >
        {/* Subtle botanical decoration */}
        <div className="absolute top-1/2 left-0 -translate-y-1/2 opacity-10 pointer-events-none" aria-hidden="true">
          <svg height="400" viewBox="0 0 300 400" width="300">
            <path d="M50 100 C150 100 150 300 250 300" fill="none" stroke="white" strokeWidth="2" />
            <circle cx="50" cy="100" fill="white" r="10" />
          </svg>
        </div>

        <div className="max-w-4xl mx-auto px-6 sm:px-12 text-center relative z-10">
          {/* Decorative quote mark */}
          <span
            className="block text-7xl md:text-8xl leading-none text-white/20 font-accent select-none mb-6"
            aria-hidden="true"
          >
            &ldquo;
          </span>

          <blockquote className="font-accent italic text-3xl sm:text-4xl md:text-5xl text-white leading-tight mb-10">
            {quote}
          </blockquote>

          {attribution && (
            <cite className="not-italic text-base sm:text-lg text-white/70 font-medium tracking-wide uppercase block">
              {attribution}
            </cite>
          )}
        </div>
      </section>
    )
  }
)
TealQuoteBlock.displayName = 'TealQuoteBlock'

export { TealQuoteBlock }
