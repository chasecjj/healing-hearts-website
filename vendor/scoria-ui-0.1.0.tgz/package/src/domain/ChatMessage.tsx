import * as React from 'react'
import { cn } from '../lib/utils'

export interface CardData {
  card_type: string
  data: Record<string, unknown>
}

export interface ChatMessageProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Message sender role */
  role: 'user' | 'assistant'
  /** Message text content */
  text: string
  /** Optional rich cards attached to the message */
  cards?: CardData[]
  /** Timestamp as a display string (e.g. "2:14 PM") */
  timestamp?: string
  /** Custom card renderer — receives card data, returns React node */
  renderCard?: (card: CardData, index: number) => React.ReactNode
}

const ChatMessage = React.forwardRef<HTMLDivElement, ChatMessageProps>(
  (
    {
      className,
      role,
      text,
      cards = [],
      timestamp,
      renderCard,
      ...props
    },
    ref
  ) => {
    const isUser = role === 'user'

    return (
      <div
        ref={ref}
        className={cn(
          'flex max-w-[88%] flex-col gap-0.5',
          isUser ? 'self-end' : 'self-start',
          className
        )}
        role="article"
        aria-label={`${isUser ? 'You' : 'Assistant'} said: ${text.slice(0, 80)}${text.length > 80 ? '...' : ''}`}
        {...props}
      >
        {/* Bubble */}
        <div
          className={cn(
            'rounded-lg px-3 py-2 font-body text-xs leading-relaxed shadow-sm transition-shadow hover:shadow-md',
            isUser
              ? 'bg-primary-500/15 text-neutral-800 rounded-br-sm'
              : 'bg-neutral-100 text-neutral-700 rounded-bl-sm'
          )}
        >
          {text}
        </div>

        {/* Rich Cards */}
        {cards.length > 0 && (
          <div className="mt-1 flex flex-col gap-1">
            {cards.map((card, i) =>
              renderCard ? (
                <React.Fragment key={i}>{renderCard(card, i)}</React.Fragment>
              ) : (
                <div
                  key={i}
                  className="rounded-md bg-neutral-100 px-3 py-2 font-body text-xs text-neutral-600"
                >
                  {card.card_type}: {JSON.stringify(card.data)}
                </div>
              )
            )}
          </div>
        )}

        {/* Timestamp */}
        {timestamp && (
          <span
            className={cn(
              'font-mono text-2xs text-neutral-400',
              isUser ? 'text-right' : 'text-left'
            )}
          >
            {timestamp}
          </span>
        )}
      </div>
    )
  }
)
ChatMessage.displayName = 'ChatMessage'

export { ChatMessage }
