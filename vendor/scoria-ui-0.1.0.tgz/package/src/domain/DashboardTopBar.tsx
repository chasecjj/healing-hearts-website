import * as React from 'react'
import { cn } from '../lib/utils'
import { Button } from '../components/button'

export interface Breadcrumb {
  label: string
  href?: string
  active?: boolean
}

export interface TopBarUser {
  name: string
  initial: string
  avatarUrl?: string
  className?: string
}

export interface DashboardTopBarProps extends React.HTMLAttributes<HTMLElement> {
  /** Breadcrumb trail */
  breadcrumbs?: Breadcrumb[]
  /** Logo text — defaults to "PHEDRIS" */
  logoText?: string
  /** Logo suffix — e.g. ".AI" */
  logoSuffix?: string
  /** Notification count — 0 hides the badge */
  notificationCount?: number
  /** Current user */
  user?: TopBarUser
  /** Callback when search is activated */
  onSearch?: () => void
  /** Callback when notification bell is clicked */
  onNotificationClick?: () => void
  /** Callback when user avatar is clicked */
  onUserClick?: () => void
  /** Search placeholder text */
  searchPlaceholder?: string
  /** Search keyboard shortcut label */
  searchShortcut?: string
}

const DashboardTopBar = React.forwardRef<HTMLElement, DashboardTopBarProps>(
  (
    {
      className,
      breadcrumbs = [],
      logoText = 'PHEDRIS',
      logoSuffix = '.AI',
      notificationCount = 0,
      user,
      onSearch,
      onNotificationClick,
      onUserClick,
      searchPlaceholder = 'Search tasks, docs, people...',
      searchShortcut = '\u2318K',
      ...props
    },
    ref
  ) => {
    return (
      <header
        ref={ref}
        className={cn(
          'flex h-12 min-h-12 items-center gap-4 px-4',
          'bg-[var(--topbar-bg,theme(colors.neutral.100))]',
          'z-10',
          className
        )}
        {...props}
      >
        {/* Left: Logo + Breadcrumbs */}
        <div className="flex min-w-0 items-center gap-3">
          <span className="whitespace-nowrap font-mono text-sm font-semibold tracking-wider text-primary-500">
            {logoText}
            {logoSuffix && (
              <span className="opacity-40">{logoSuffix}</span>
            )}
          </span>

          {breadcrumbs.length > 0 && (
            <nav aria-label="Breadcrumb">
              <ol className="flex items-center gap-1.5">
                {breadcrumbs.map((crumb, i) => (
                  <li key={crumb.label} className="flex items-center gap-1.5">
                    {i > 0 && (
                      <svg
                        className="h-3 w-3 shrink-0 opacity-35"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        aria-hidden="true"
                      >
                        <path d="M9 18l6-6-6-6" />
                      </svg>
                    )}
                    {crumb.href && !crumb.active ? (
                      <a
                        href={crumb.href}
                        className="whitespace-nowrap font-body text-xs text-neutral-400 hover:text-neutral-600"
                      >
                        {crumb.label}
                      </a>
                    ) : (
                      <span
                        className={cn(
                          'whitespace-nowrap font-body text-xs',
                          crumb.active ? 'font-medium text-neutral-700' : 'text-neutral-400'
                        )}
                        aria-current={crumb.active ? 'page' : undefined}
                      >
                        {crumb.label}
                      </span>
                    )}
                  </li>
                ))}
              </ol>
            </nav>
          )}
        </div>

        {/* Center: Search */}
        <div className="flex min-w-0 flex-1 justify-center">
          <button
            onClick={onSearch}
            className={cn(
              'flex w-full max-w-[380px] items-center gap-2 rounded-md border px-3 py-1.5',
              'cursor-pointer transition-colors',
              'bg-neutral-100 border-neutral-200 hover:border-neutral-300',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2'
            )}
            aria-label="Open search"
          >
            <svg
              className="h-3.5 w-3.5 shrink-0 text-neutral-400"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              aria-hidden="true"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
            <span className="flex-1 truncate text-left font-body text-xs text-neutral-400">
              {searchPlaceholder}
            </span>
            {searchShortcut && (
              <kbd className="shrink-0 rounded border border-neutral-200 bg-neutral-50 px-1.5 py-px font-mono text-2xs text-neutral-400">
                {searchShortcut}
              </kbd>
            )}
          </button>
        </div>

        {/* Right: Notifications + User */}
        <div className="flex shrink-0 items-center gap-3">
          {/* Notification Bell */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onNotificationClick}
            aria-label={`Notifications${notificationCount > 0 ? `, ${notificationCount} unread` : ''}`}
            className="relative text-neutral-400 hover:text-neutral-600"
          >
            <svg
              className="h-[18px] w-[18px]"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              aria-hidden="true"
            >
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 01-3.46 0" />
            </svg>
            {notificationCount > 0 && (
              <span
                className={cn(
                  'absolute -right-1 -top-0.5',
                  'flex h-4 w-4 items-center justify-center rounded-full',
                  'bg-error text-2xs font-semibold text-white',
                  'border-2 border-[var(--topbar-bg,theme(colors.neutral.100))]'
                )}
                aria-hidden="true"
              >
                {notificationCount > 9 ? '9+' : notificationCount}
              </span>
            )}
          </Button>

          {/* User */}
          {user && (
            <button
              onClick={onUserClick}
              className={cn(
                'flex items-center gap-2 whitespace-nowrap',
                'cursor-pointer',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2 rounded'
              )}
              aria-label={`User menu for ${user.name}`}
            >
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={`${user.name}'s avatar`}
                  className="h-[26px] w-[26px] rounded-full object-cover"
                />
              ) : (
                <div
                  className={cn(
                    'flex h-[26px] w-[26px] items-center justify-center rounded-full',
                    'font-body text-xs font-semibold text-white',
                    user.className ?? 'bg-primary-500'
                  )}
                  aria-hidden="true"
                >
                  {user.initial}
                </div>
              )}
              <span className="hidden font-body text-xs text-neutral-600 sm:inline">
                {user.name}
              </span>
            </button>
          )}
        </div>
      </header>
    )
  }
)
DashboardTopBar.displayName = 'DashboardTopBar'

export { DashboardTopBar }
