import * as React from 'react'
import { cn } from '../lib/utils'
import { Card } from '../components/card'

export interface DayItem {
  day: number
  title: string
  description: string
}

export interface DailyBreakdownGridProps extends React.HTMLAttributes<HTMLElement> {
  days: DayItem[]
  heading?: string
}

const DailyBreakdownGrid = React.forwardRef<HTMLElement, DailyBreakdownGridProps>(
  ({ className, days, heading, ...props }, ref) => {
    return (
      <section
        ref={ref}
        className={cn('mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8', className)}
        {...props}
      >
        {heading && (
          <h2 className="font-heading text-3xl font-bold tracking-tight text-neutral-800 sm:text-4xl">
            {heading}
          </h2>
        )}
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Row 1: 4 cards on lg, 2+2 on sm, stacked on mobile */}
          {days.slice(0, 4).map((item) => (
            <Card
              key={item.day}
              className="rounded-2xl border border-neutral-200 bg-neutral-50 p-6 shadow-[0_4px_20px_-4px_rgba(7,58,71,0.08)] transition-all duration-200 hover:shadow-[0_8px_30px_-4px_rgba(7,58,71,0.12)] hover:scale-[1.02]"
            >
              <span className="font-mono text-xs font-medium uppercase tracking-widest text-primary-500">
                Day {item.day}
              </span>
              <h3 className="mt-2 font-heading text-lg font-semibold leading-heading text-neutral-800">
                {item.title}
              </h3>
              <p className="mt-2 font-body text-sm leading-body text-neutral-600">
                {item.description}
              </p>
            </Card>
          ))}
        </div>
        {/* Row 2: asymmetric — 2 wider + 1 on lg */}
        {days.length > 4 && (
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {days.slice(4).map((item) => (
              <Card
                key={item.day}
                className="rounded-2xl border border-neutral-200 bg-neutral-50 p-6 shadow-[0_4px_20px_-4px_rgba(7,58,71,0.08)] transition-all duration-200 hover:shadow-[0_8px_30px_-4px_rgba(7,58,71,0.12)] hover:scale-[1.02]"
              >
                <span className="font-mono text-xs font-medium uppercase tracking-widest text-primary-500">
                  Day {item.day}
                </span>
                <h3 className="mt-2 font-heading text-lg font-semibold leading-heading text-neutral-800">
                  {item.title}
                </h3>
                <p className="mt-2 font-body text-sm leading-body text-neutral-600">
                  {item.description}
                </p>
              </Card>
            ))}
          </div>
        )}
      </section>
    )
  }
)
DailyBreakdownGrid.displayName = 'DailyBreakdownGrid'

export { DailyBreakdownGrid }
