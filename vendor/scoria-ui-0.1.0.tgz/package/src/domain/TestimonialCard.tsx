import * as React from 'react'
import { cn } from '../lib/utils'
import { Card } from '../components/card'

export interface TestimonialCardProps extends React.HTMLAttributes<HTMLDivElement> {
  quote: string
  name: string
  role?: string
}

const TestimonialCard = React.forwardRef<HTMLDivElement, TestimonialCardProps>(
  ({ className, quote, name, role, ...props }, ref) => {
    return (
      <Card
        ref={ref}
        className={cn(
          'rounded-2xl border-l-4 border-l-primary-200 bg-accent-50 p-8 shadow-[0_4px_20px_-4px_rgba(7,58,71,0.08)]',
          className
        )}
        {...props}
      >
        <blockquote className="font-accent text-xl italic leading-body text-neutral-700 sm:text-2xl">
          &ldquo;{quote}&rdquo;
        </blockquote>
        <p className="mt-4 font-body text-sm text-neutral-500">
          &mdash; {name}{role && `, ${role}`}
        </p>
      </Card>
    )
  }
)
TestimonialCard.displayName = 'TestimonialCard'

export { TestimonialCard }
