// @scoria/ui — shared component library

// Base components (shadcn/ui)
export { Button, type ButtonProps, buttonVariants } from './components/button'
export { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from './components/card'
export { Dialog, DialogPortal, DialogOverlay, DialogTrigger, DialogClose, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription } from './components/dialog'
export { Input, type InputProps } from './components/input'

// Utilities
export { cn } from './lib/utils'

// Domain components
export { HeroSection, type HeroSectionProps } from './domain/HeroSection'
export { PricingCard, type PricingCardProps } from './domain/PricingCard'
export { CoursePlayer, type CoursePlayerProps } from './domain/CoursePlayer'

// PHEDRIS Dashboard domain components
export { DashboardSidebar, type DashboardSidebarProps, type NavItem, type TeamMember } from './domain/DashboardSidebar'
export { DashboardTopBar, type DashboardTopBarProps, type Breadcrumb, type TopBarUser } from './domain/DashboardTopBar'
export { TaskCard, type TaskCardProps, type TaskProject, type TaskAssignee, type TaskLabel, type TaskPriority, type TaskStatus, taskCardVariants } from './domain/TaskCard'
export { KanbanColumn, type KanbanColumnProps } from './domain/KanbanColumn'
export { ChatMessage, type ChatMessageProps, type CardData } from './domain/ChatMessage'
export { ChatInput, type ChatInputProps } from './domain/ChatInput'
export { ActivityItem, type ActivityItemProps, type ActivityProjectTag } from './domain/ActivityItem'
