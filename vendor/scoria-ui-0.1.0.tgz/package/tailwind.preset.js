/** @type {import('tailwindcss').Config} */
export default {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#e6f5f8',
          100: '#c0e5ec',
          200: '#96d4df',
          300: '#6bc3d2',
          400: '#41b2c5',
          500: '#1191B1',
          600: '#0e748e',
          700: '#0b576b',
          800: '#073a47',
          900: '#041d24',
        },
        accent: {
          50: '#f8f0ee',
          100: '#ecd6d1',
          200: '#dfbbb3',
          300: '#d2a095',
          400: '#c58577',
          500: '#B96A5F',
          600: '#94554c',
          700: '#6f4039',
          800: '#4a2b26',
          900: '#251513',
        },
        neutral: {
          50: '#fafafa',
          100: '#f5f5f5',
          200: '#e5e5e5',
          300: '#d4d4d4',
          400: '#a3a3a3',
          500: '#737373',
          600: '#525252',
          700: '#404040',
          800: '#262626',
          900: '#171717',
        },
        success: '#22c55e',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6',
      },
      fontFamily: {
        heading: ['Outfit', 'sans-serif'],
        body: ['Plus Jakarta Sans', 'sans-serif'],
        accent: ['Cormorant Garamond', 'serif'],
        mono: ['IBM Plex Mono', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
      },
      lineHeight: {
        body: '1.6',
        heading: '1.2',
      },
    },
  },
}
